# -*- coding: utf-8 -*-

#
# License: MIT
# Copyright: Patrick Ng - 2012
#

from .retry_decorator import *

__title__ = 'retry_decorator'
__version__ = "1.1.1"
